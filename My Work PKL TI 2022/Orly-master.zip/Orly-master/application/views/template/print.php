<? defined('SYSPATH') or die('No direct script access.'); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Kekerasan BP3AKB Jateng</title>

<link href="<? echo URL::base(); ?>assets/css/print.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="content"><? echo $content; ?></div>
</body>
</html>