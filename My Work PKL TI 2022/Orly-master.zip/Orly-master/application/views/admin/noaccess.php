<? defined('SYSPATH') or die('No direct script access.'); ?>

<body>
<div class="notes">Maaf, Anda tidak berhak mengakses halaman ini<br><br>
Hubungi Admin Dinas atau Administrator untuk mendapatkan info lebih lanjut</div>
</body>