<?
defined('SYSPATH') or die('No direct script access.');

echo $surat->description;
?>