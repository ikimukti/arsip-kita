<?
defined('SYSPATH') or die('No direct script access.');

class Model_Viewkeluar extends ORM {	
}
?>