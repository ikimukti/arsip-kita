<?
defined('SYSPATH') or die('No direct script access.');

class Model_Viewpemberkasan extends ORM {	
}
?>