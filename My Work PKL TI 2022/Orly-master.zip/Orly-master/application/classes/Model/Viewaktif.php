<?
defined('SYSPATH') or die('No direct script access.');

class Model_Viewaktif extends ORM {	
	protected $_belongs_to = array(
		'keterangan'	=> array(),
	);
}
?>