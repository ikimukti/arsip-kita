<?
defined('SYSPATH') or die('No direct script access.');

class Model_Masterbool extends ORM {
}
?>