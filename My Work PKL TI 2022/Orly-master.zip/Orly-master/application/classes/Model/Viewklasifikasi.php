<?
defined('SYSPATH') or die('No direct script access.');

class Model_Viewklasifikasi extends ORM {
}
?>