<?
defined('SYSPATH') or die('No direct script access.');

class Model_Viewinaktif extends ORM {	
}
?>