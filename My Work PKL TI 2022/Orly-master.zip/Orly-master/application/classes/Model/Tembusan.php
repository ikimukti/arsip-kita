<?
defined('SYSPATH') or die('No direct script access.');

class Model_Tembusan extends ORM {
	protected $_belongs_to = array(
		'sotk'	=> array(),
	);
}
?>