<?php

return array(
 	'password' => array(
        'min_length' => 'Password minimal 4 karakter',
    ),
	'password_confirm' => array(
        'matches' => 'Retype Password harus sesuai',
    ),
);