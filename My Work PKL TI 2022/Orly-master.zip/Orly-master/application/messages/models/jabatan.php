<? 
defined('SYSPATH') OR die('No direct access allowed.');

return array 
( 
	'name' => array(
		'not_empty'			=> 'Nama Jabatan harus diisi',
		'name_available'	=> 'Nama Jabatan sudah terpakai',
	),
); 