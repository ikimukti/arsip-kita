<?php defined('SYSPATH') or die('No direct access allowed.');

return array
(
	'default' => array(
		'type'       => 'MySQL',
		'connection' => array(
			'persistent' => FALSE,
			'hostname'   => 'localhost',
			'username'   => 'arsipsem_user',
			'password'   => '#hDfHv#ia1Dg',
			'database'   => 'arsipsem_arsipsmg',
		),
		'table_prefix' => '',
		'charset'      => 'utf8',
		'caching'      => FALSE,
		'profiling'    => TRUE,
	)
);