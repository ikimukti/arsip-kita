<?
defined('SYSPATH') OR die('No direct access allowed.');

return array (
	'items_per_pages' 			=> 18,
	'items_per_pages_search' 	=> 12,
	'config_dir_doc' 			=> '/home/arsipsemarangkot/public_html/assets/doc',
	'config_dir_user' 			=> '/home/arsipsemarangkot/public_html/assets/user',
	'push_notification'			=> 0,
	'title' 						=> 'E-Surat Kota Semarang',
);
?>