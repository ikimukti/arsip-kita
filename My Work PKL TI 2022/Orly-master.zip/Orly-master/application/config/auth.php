<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'driver'       => 'ORM',
	'hash_method'  => 'md5',
	'hash_key'     => 'V3 SEMARANG KOTA 2018 Y3S!23',
	'lifetime'     => 3600,
	'session_type' => Session::$default,
	'session_key'  => 'auth_user'
);
?>