<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2018-07-03 06:19:46 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: captcha ~ APPPATH/classes/Controller/Register.php [ 15 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Register.php:15
2018-07-03 06:19:46 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Register.php(15): Kohana_Core::error_handler(8, 'Undefined index...', '/Volumes/MacDat...', 15, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Register->action_login()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Register))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Register.php:15
2018-07-03 08:43:06 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: masuk ~ APPPATH/classes/Controller/Admin/Masuk.php [ 241 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:241
2018-07-03 08:43:06 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(241): Kohana_Core::error_handler(8, 'Undefined varia...', '/Volumes/MacDat...', 241, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:241
2018-07-03 08:43:17 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: masuk ~ APPPATH/classes/Controller/Admin/Masuk.php [ 241 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:241
2018-07-03 08:43:17 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(241): Kohana_Core::error_handler(8, 'Undefined varia...', '/Volumes/MacDat...', 241, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:241
2018-07-03 08:43:54 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: masuk ~ APPPATH/classes/Controller/Admin/Masuk.php [ 241 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:241
2018-07-03 08:43:54 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(241): Kohana_Core::error_handler(8, 'Undefined varia...', '/Volumes/MacDat...', 241, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:241
2018-07-03 10:07:18 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: start ~ APPPATH/classes/Controller/Admin/Masuk.php [ 249 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:249
2018-07-03 10:07:18 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(249): Kohana_Core::error_handler(8, 'Undefined index...', '/Volumes/MacDat...', 249, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:249
2018-07-03 10:07:35 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: start ~ APPPATH/classes/Controller/Admin/Masuk.php [ 249 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:249
2018-07-03 10:07:35 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(249): Kohana_Core::error_handler(8, 'Undefined index...', '/Volumes/MacDat...', 249, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:249
2018-07-03 10:07:37 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: start ~ APPPATH/classes/Controller/Admin/Masuk.php [ 249 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:249
2018-07-03 10:07:37 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(249): Kohana_Core::error_handler(8, 'Undefined index...', '/Volumes/MacDat...', 249, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#2 [internal function]: Kohana_Controller->execute()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#7 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php:249
2018-07-03 10:08:00 --- EMERGENCY: Database_Exception [ 1054 ]: Unknown column 'keyword' in 'where clause' [ SELECT COUNT(`masuk`.`id`) AS `records_found` FROM `masuks` AS `masuk` WHERE `keyword` LIKE '%%' ] ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 194 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php:251
2018-07-03 10:08:00 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php(251): Kohana_Database_MySQL->query(1, 'SELECT COUNT(`m...', false, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(1648): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(246): Kohana_ORM->count_all()
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#4 [internal function]: Kohana_Controller->execute()
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#9 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php:251
2018-07-03 10:14:08 --- EMERGENCY: Kohana_Exception [ 0 ]: The user property does not exist in the Model_Viewmasuk class ~ MODPATH/orm/classes/Kohana/ORM.php [ 687 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:14:08 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(603): Kohana_ORM->get('user')
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(278): Kohana_ORM->__get('user')
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#3 [internal function]: Kohana_Controller->execute()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#8 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:14:28 --- EMERGENCY: Kohana_Exception [ 0 ]: The user property does not exist in the Model_Viewmasuk class ~ MODPATH/orm/classes/Kohana/ORM.php [ 687 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:14:28 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(603): Kohana_ORM->get('user')
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(278): Kohana_ORM->__get('user')
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#3 [internal function]: Kohana_Controller->execute()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#8 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:35:27 --- EMERGENCY: Kohana_Exception [ 0 ]: The masterjabatan_id property does not exist in the Model_User class ~ MODPATH/orm/classes/Kohana/ORM.php [ 687 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:35:27 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(603): Kohana_ORM->get('masterjabatan_i...')
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(242): Kohana_ORM->__get('masterjabatan_i...')
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#3 [internal function]: Kohana_Controller->execute()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#8 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:35:35 --- EMERGENCY: Kohana_Exception [ 0 ]: The masterjabatan_id property does not exist in the Model_User class ~ MODPATH/orm/classes/Kohana/ORM.php [ 687 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 10:35:35 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(603): Kohana_ORM->get('masterjabatan_i...')
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Masuk.php(242): Kohana_ORM->__get('masterjabatan_i...')
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Masuk->action_data()
#3 [internal function]: Kohana_Controller->execute()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Masuk))
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#8 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php:603
2018-07-03 11:57:44 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Viewkeluar' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2018-07-03 11:57:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2018-07-03 11:58:18 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Viewkeluar' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2018-07-03 11:58:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2018-07-03 11:58:56 --- EMERGENCY: Database_Exception [ 1054 ]: Unknown column 'tanggal_terima' in 'order clause' [ SELECT `viewkeluar`.`id` AS `id`, `viewkeluar`.`skpd_id` AS `skpd_id`, `viewkeluar`.`kepada` AS `kepada`, `viewkeluar`.`name` AS `name`, `viewkeluar`.`tanggal` AS `tanggal`, `viewkeluar`.`tanggal_surat` AS `tanggal_surat`, `viewkeluar`.`tingkat_id` AS `tingkat_id`, `viewkeluar`.`jumlah` AS `jumlah`, `viewkeluar`.`lampiran_id` AS `lampiran_id`, `viewkeluar`.`file` AS `file`, `viewkeluar`.`urut` AS `urut`, `viewkeluar`.`nomor` AS `nomor`, `viewkeluar`.`perihal` AS `perihal`, `viewkeluar`.`klasifikasi_id` AS `klasifikasi_id`, `viewkeluar`.`isi` AS `isi`, `viewkeluar`.`indeks` AS `indeks`, `viewkeluar`.`sotk_id` AS `sotk_id`, `viewkeluar`.`guna_id` AS `guna_id`, `viewkeluar`.`media_id` AS `media_id`, `viewkeluar`.`retensi_aktif` AS `retensi_aktif`, `viewkeluar`.`retensi_inaktif` AS `retensi_inaktif`, `viewkeluar`.`tahun_aktif` AS `tahun_aktif`, `viewkeluar`.`tahun_inaktif` AS `tahun_inaktif`, `viewkeluar`.`keterangan_retensi` AS `keterangan_retensi`, `viewkeluar`.`keterangan_id` AS `keterangan_id`, `viewkeluar`.`mastersurat_id` AS `mastersurat_id`, `viewkeluar`.`draft_id` AS `draft_id`, `viewkeluar`.`user_id` AS `user_id`, `viewkeluar`.`created` AS `created`, `viewkeluar`.`updated` AS `updated`, `viewkeluar`.`skpd_name` AS `skpd_name`, `viewkeluar`.`kode` AS `kode`, `viewkeluar`.`keyword` AS `keyword` FROM `viewkeluars` AS `viewkeluar` WHERE `skpd_id` = '33' AND `keyword` LIKE '%%' ORDER BY `tanggal_terima` ASC LIMIT 10 OFFSET 0 ] ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 194 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php:251
2018-07-03 11:58:56 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `viewkel...', 'Model_Viewkelua...', Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(1063): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(1004): Kohana_ORM->_load_result(true)
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Keluar.php(296): Kohana_ORM->find_all()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Keluar->action_data()
#5 [internal function]: Kohana_Controller->execute()
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Keluar))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#10 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php:251
2018-07-03 12:00:51 --- EMERGENCY: Database_Exception [ 1054 ]: Unknown column 'tanggal_terima' in 'order clause' [ SELECT `viewkeluar`.`id` AS `id`, `viewkeluar`.`skpd_id` AS `skpd_id`, `viewkeluar`.`kepada` AS `kepada`, `viewkeluar`.`name` AS `name`, `viewkeluar`.`tanggal` AS `tanggal`, `viewkeluar`.`tanggal_surat` AS `tanggal_surat`, `viewkeluar`.`tingkat_id` AS `tingkat_id`, `viewkeluar`.`jumlah` AS `jumlah`, `viewkeluar`.`lampiran_id` AS `lampiran_id`, `viewkeluar`.`file` AS `file`, `viewkeluar`.`urut` AS `urut`, `viewkeluar`.`nomor` AS `nomor`, `viewkeluar`.`perihal` AS `perihal`, `viewkeluar`.`klasifikasi_id` AS `klasifikasi_id`, `viewkeluar`.`isi` AS `isi`, `viewkeluar`.`indeks` AS `indeks`, `viewkeluar`.`sotk_id` AS `sotk_id`, `viewkeluar`.`guna_id` AS `guna_id`, `viewkeluar`.`media_id` AS `media_id`, `viewkeluar`.`retensi_aktif` AS `retensi_aktif`, `viewkeluar`.`retensi_inaktif` AS `retensi_inaktif`, `viewkeluar`.`tahun_aktif` AS `tahun_aktif`, `viewkeluar`.`tahun_inaktif` AS `tahun_inaktif`, `viewkeluar`.`keterangan_retensi` AS `keterangan_retensi`, `viewkeluar`.`keterangan_id` AS `keterangan_id`, `viewkeluar`.`mastersurat_id` AS `mastersurat_id`, `viewkeluar`.`draft_id` AS `draft_id`, `viewkeluar`.`user_id` AS `user_id`, `viewkeluar`.`created` AS `created`, `viewkeluar`.`updated` AS `updated`, `viewkeluar`.`skpd_name` AS `skpd_name`, `viewkeluar`.`kode` AS `kode`, `viewkeluar`.`keyword` AS `keyword` FROM `viewkeluars` AS `viewkeluar` WHERE `skpd_id` = '33' AND `keyword` LIKE '%%' ORDER BY `tanggal_terima` ASC LIMIT 10 OFFSET 0 ] ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 194 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php:251
2018-07-03 12:00:51 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `viewkel...', 'Model_Viewkelua...', Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(1063): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/orm/classes/Kohana/ORM.php(1004): Kohana_ORM->_load_result(true)
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Keluar.php(296): Kohana_ORM->find_all()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(84): Controller_Admin_Keluar->action_data()
#5 [internal function]: Kohana_Controller->execute()
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Keluar))
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#10 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/modules/database/classes/Kohana/Database/Query.php:251
2018-07-03 23:40:29 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/views/admin/instansi.php [ 4 ] in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/views/admin/instansi.php:4
2018-07-03 23:40:29 --- DEBUG: #0 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/views/admin/instansi.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', '/Volumes/MacDat...', 4, Array)
#1 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/View.php(62): include('/Volumes/MacDat...')
#2 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/View.php(359): Kohana_View::capture('/Volumes/MacDat...', Array)
#3 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/View.php(236): Kohana_View->render()
#4 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/views/template/backend.php(210): Kohana_View->__toString()
#5 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/View.php(62): include('/Volumes/MacDat...')
#6 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/View.php(359): Kohana_View::capture('/Volumes/MacDat...', Array)
#7 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#8 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/classes/Controller/Admin/Backend.php(39): Kohana_Controller_Template->after()
#9 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Controller.php(87): Controller_Admin_Backend->after()
#10 [internal function]: Kohana_Controller->execute()
#11 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Inaktif))
#12 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/index.php(109): Kohana_Request->execute()
#15 {main} in /Volumes/MacData/Projects/www/arsip_dinamis_master_v3/application/views/admin/instansi.php:4