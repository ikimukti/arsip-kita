<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2019-09-20 07:33:55 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:33:55 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:33:58 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:33:58 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:33:59 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:33:59 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:00 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:00 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:13 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:13 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:13 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:13 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:14 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:14 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:16 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:16 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:16 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:16 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:17 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:17 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:17 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:17 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:18 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:18 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:18 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:18 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:19 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:20 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:20 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:20 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:20 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:20 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:20 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:32 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 07:34:32 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 11:12:52 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 11:12:52 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 11:12:59 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: file ~ APPPATH/classes/Controller/Dinas/Masuk.php [ 67 ] in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67
2019-09-20 11:12:59 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php(67): Kohana_Core::error_handler(8, 'Undefined index...', '/home/arsipsema...', 67, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Masuk->action_save()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Masuk))
#4 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#7 {main} in /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Masuk.php:67