<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2019-05-03 13:44:22 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: skpd ~ APPPATH/views/dinas/sotk_form.php [ 9 ] in /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php:9
2019-05-03 13:44:22 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/arsipsema...', 9, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(62): include('/home/arsipsema...')
#2 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/arsipsema...', Array)
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(236): Kohana_View->render()
#4 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Sotk.php(91): Kohana_View->__toString()
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Sotk->action_save()
#6 [internal function]: Kohana_Controller->execute()
#7 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Sotk))
#8 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#10 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#11 {main} in /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php:9
2019-05-03 13:44:28 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: skpd ~ APPPATH/views/dinas/sotk_form.php [ 9 ] in /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php:9
2019-05-03 13:44:28 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/arsipsema...', 9, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(62): include('/home/arsipsema...')
#2 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/arsipsema...', Array)
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(236): Kohana_View->render()
#4 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Sotk.php(91): Kohana_View->__toString()
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Sotk->action_save()
#6 [internal function]: Kohana_Controller->execute()
#7 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Sotk))
#8 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#10 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#11 {main} in /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php:9
2019-05-03 13:44:48 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: skpd ~ APPPATH/views/dinas/sotk_form.php [ 9 ] in /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php:9
2019-05-03 13:44:48 --- DEBUG: #0 /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/arsipsema...', 9, Array)
#1 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(62): include('/home/arsipsema...')
#2 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/arsipsema...', Array)
#3 /home/arsipsemarangkot/public_html/system/classes/Kohana/View.php(236): Kohana_View->render()
#4 /home/arsipsemarangkot/public_html/application/classes/Controller/Dinas/Sotk.php(91): Kohana_View->__toString()
#5 /home/arsipsemarangkot/public_html/system/classes/Kohana/Controller.php(84): Controller_Dinas_Sotk->action_save()
#6 [internal function]: Kohana_Controller->execute()
#7 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dinas_Sotk))
#8 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 /home/arsipsemarangkot/public_html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#10 /home/arsipsemarangkot/public_html/index.php(109): Kohana_Request->execute()
#11 {main} in /home/arsipsemarangkot/public_html/application/views/dinas/sotk_form.php:9